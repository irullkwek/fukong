const fetch = require('node-fetch');
const crypto = require('crypto');
const FormData = require('form-data');
const { fromBuffer } = require('file-type');
const fs = require('fs');
const baileys = require('baileys');

const commandList = ["upsw"];
const mimeAudio = 'audio/mpeg';
const mimeVideo = 'video/mp4';
const mimeImage = 'image/jpeg';

async function uploadcatbox(buffer) {
    const { ext } = await fromBuffer(buffer);
    const form = new FormData();
    form.append('fileToUpload', buffer, `file.${ext}`);
    form.append('reqtype', 'fileupload');
    
    const res = await fetch("https://catbox.moe/user/api.php", {
        method: "POST",
        body: form
    });

    if (!res.ok) throw new Error('Upload gagal: ' + res.statusText);
    return await res.text();
}

const fetchParticipants = async (conn, ...jids) => {
    let results = [];
    
    for (const jid of jids) {
        try {
            const { participants } = await conn.groupMetadata(jid);
            results = results.concat(participants.map(p => p.id));
        } catch (err) {
            console.error(`Gagal mengambil data grup ${jid}:`, err);
        }
    }
    
    return results;
};

async function mentionStatus(conn, jids, content) {
    const msg = await baileys.generateWAMessage(baileys.STORIES_JID, content, {
        upload: conn.waUploadToServer
    });

    let statusJidList = [];
    
    for (const _jid of jids) {
        if (_jid.endsWith("@g.us")) {
            const groupParticipants = await fetchParticipants(conn, _jid);
            statusJidList.push(...groupParticipants);
        } else {
            statusJidList.push(_jid);
        }
    }

    statusJidList = [...new Set(statusJidList)];

    await conn.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id,
        statusJidList,
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: jids.map(jid => ({
                    tag: "to",
                    attrs: { jid },
                    content: undefined
                }))
            }]
        }]
    });

    for (const jid of jids) {
        const type = jid.endsWith("@g.us") ? "groupStatusMentionMessage" : "statusMentionMessage";
        await conn.relayMessage(jid, {
            [type]: {
                message: {
                    protocolMessage: {
                        key: msg.key,
                        type: 25
                    }
                }
            }
        }, {
            additionalNodes: [{
                tag: "meta",
                attrs: { is_status_mention: "true" },
                content: undefined
            }]
        });
    }

    return msg;
}

// Function to split array into chunks of specified size
function chunkArray(array, size) {
    const chunks = [];
    for (let i = 0; i < array.length; i += size) {
        chunks.push(array.slice(i, i + size));
    }
    return chunks;
}

// Function to add delay between batches
function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

let handler = async (m, { conn, command, args }) => {
    let targetGroups = args.includes("--allgc") ? [] : args.filter(arg => arg.endsWith('@g.us'));

    if (args.includes("--allgc")) {
        const allGroups = await conn.groupFetchAllParticipating();
        targetGroups = Object.keys(allGroups);
    }

    if (targetGroups.length === 0) {
        return conn.reply(m.chat, "❌ Harap tentukan grup target atau gunakan `--allgc` untuk mengirim ke semua grup!", m);
    }

    const messageText = args.filter(arg => !arg.endsWith('@g.us') && arg !== "--allgc").join(" ");
    
    if (!messageText && !m.quoted) {
        return conn.reply(m.chat, "❌ Harap berikan pesan atau balas media!", m);
    }

    let openGroups = [];
    let skippedGroups = [];

    for (const jid of targetGroups) {
        try {
            const metadata = await conn.groupMetadata(jid);
            if (metadata.announce) skippedGroups.push(jid);
            else openGroups.push(jid);
        } catch (err) {
            console.error(`Gagal memproses grup ${jid}:`, err);
        }
    }

    if (openGroups.length === 0) {
        let report = `*乂 U P - S W*\n\n`;
        report += `> *◦ Berhasil dikirim ke*: 0 grup\n`;
        report += `> *◦ Grup dilewati (tertutup)*: ${skippedGroups.length} grup\n`;
        return conn.reply(m.chat, report, m);
    }

    // Split groups into batches of 5
    const groupBatches = chunkArray(openGroups, 5);
    let totalSent = 0;
    let totalFailed = 0;

    // Send initial report
    let initialReport = `*乂 U P - S W*\n\n`;
    initialReport += `> *◦ Total grup terbuka*: ${openGroups.length} grup\n`;
    initialReport += `> *◦ Grup dilewati (tertutup)*: ${skippedGroups.length} grup\n`;
    initialReport += `> *◦ Jumlah batch*: ${groupBatches.length} batch (5 grup per batch)\n`;
    initialReport += `> *◦ Status*: Memulai pengiriman...\n`;
    
    await conn.reply(m.chat, initialReport, m);

    // Process each batch
    for (let i = 0; i < groupBatches.length; i++) {
        const batch = groupBatches[i];
        const batchNumber = i + 1;
        
        try {
            if (m.quoted && m.quoted.mtype) {
                const mtype = m.quoted.mtype;
                let doc = {};

                const media = await m.quoted.download();
                const { ext } = await fromBuffer(media);
                const url = await uploadcatbox(media);

                if (mtype === 'audioMessage') {
                    doc.mimetype = mimeAudio;
                    doc.audio = { url };
                } else if (mtype === 'videoMessage') {
                    doc.mimetype = mimeVideo;
                    doc.caption = messageText || '';
                    doc.video = { url };
                } else if (mtype === 'imageMessage') {
                    doc.mimetype = mimeImage;
                    doc.caption = messageText || '';
                    doc.image = { url };
                } else {
                    return conn.reply(m.chat, "❌ Jenis media tidak didukung! Hanya audio, video, atau gambar.", m);
                }

                await mentionStatus(conn, batch, doc);
                totalSent += batch.length;
                
            } else if (messageText) {
                await mentionStatus(conn, batch, { text: messageText });
                totalSent += batch.length;
            }

            // Send progress update
            const progressReport = `*Batch ${batchNumber}/${groupBatches.length} selesai!*\n> Berhasil: ${batch.length} grup\n> Total terkirim: ${totalSent}/${openGroups.length} grup`;
            await conn.reply(m.chat, progressReport, m);

            // Add delay between batches (2 seconds)
            if (i < groupBatches.length - 1) {
                await delay(2000);
            }

        } catch (error) {
            totalFailed += batch.length;
            console.error(`Batch ${batchNumber} gagal:`, error);
            
            const errorReport = `*Batch ${batchNumber}/${groupBatches.length} gagal!*\n> Gagal: ${batch.length} grup\n> Error: ${error.message}`;
            await conn.reply(m.chat, errorReport, m);
        }
    }

    // Send final report
    let finalReport = `*乂 U P - S W (SELESAI)*\n\n`;
    finalReport += `> *◦ Total berhasil dikirim*: ${totalSent} grup\n`;
    finalReport += `> *◦ Total gagal*: ${totalFailed} grup\n`;
    finalReport += `> *◦ Grup dilewati (tertutup)*: ${skippedGroups.length} grup\n`;
    finalReport += `> *◦ Total batch diproses*: ${groupBatches.length} batch\n`;

    await conn.reply(m.chat, finalReport, m);
};

handler.help = commandList;
handler.tags = ["owner"];
handler.rowner = true;
handler.command = new RegExp(`^(${commandList.join('|')})$`, 'i');

module.exports = handler;