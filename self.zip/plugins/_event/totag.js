let handler = async (m, { conn, text, isAdmin, participants}) => {
	
    let users = participants.map(u => u.id).filter(v => v !== conn.user.jid)
    if (!m.quoted) return m.reply(`Reply pesan text/media`)
    conn.sendMessage(m.chat, { forward: m.quoted.fakeObj, mentions: users } )
}

handler.command = ["totag"]
handler.owner = true

module.exports = handler