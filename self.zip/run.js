const { spawn } = require("child_process")

function start(cmd) {
  return spawn(cmd, [], {
      stdio: ["inherit", "inherit", "inherit", "ipc"],
  })
}
start("bash")